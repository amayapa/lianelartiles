---
name: Icon request
about: Requesting a new icon or changes to an existing icon
title: 'Icon request: [NAME]'
labels: 'request: icon'
assignees: ''

---

### About the icon
*Short description why you think this icon is matching in our project*
### Links
*Provide helpful links which can be used to take a deeper look into the icon and provide, if available, some resources (svg's) where the icon can be found*
### Preview
*If available, provide some images of the icon you would like to be added*
